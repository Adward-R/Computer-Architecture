The following files were generated for 'dmem' in directory
D:\LAB5\ipcore_dir\

Opens the IP Customization GUI:
   Allows the user to customize or recustomize the IP instance.

   * dmem.mif

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * dmem.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * blk_mem_gen_ds512.pdf
   * dmem.ngc
   * dmem.v
   * dmem.veo

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * dmem.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * dmem.asy
   * dmem.mif

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * dmem.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * dmem_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * dmem.gise
   * dmem.xise

Deliver Readme:
   Readme file for the IP.

   * dmem_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * dmem_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.


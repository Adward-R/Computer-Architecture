The following files were generated for 'imem' in directory
D:\LAB5\ipcore_dir\

Opens the IP Customization GUI:
   Allows the user to customize or recustomize the IP instance.

   * imem.mif

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * imem.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * blk_mem_gen_ds512.pdf
   * imem.ngc
   * imem.v
   * imem.veo

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * imem.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * imem.asy
   * imem.mif

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * imem.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * imem_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * imem.gise
   * imem.xise

Deliver Readme:
   Readme file for the IP.

   * imem_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * imem_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

